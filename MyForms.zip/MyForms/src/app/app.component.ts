import { Component, OnInit } from '@angular/core';

import {map }  from 'rxjs/operators';
import {of, Observable} from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyForms';



   


    

      nums = of(1,2,3,4);


        squareValues =    map((n1:number)=>n1*n1);



            
            squareNums  =  this.squareValues(this.nums).subscribe(x=>console.log(x),error=>console.log(error));

 

              

  
          



/*  eid;
  ename;


  getFormData(data){

    alert(data.value.eid +" "+data.value.ename);



  }
*/

}



