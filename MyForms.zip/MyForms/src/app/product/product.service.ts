import { Injectable } from '@angular/core';

import {HttpClient} from '@angular/common/http';

import {Product} from './product'; 

import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

    readonly url:string = "assets/product.json";

  constructor(private   _http:HttpClient) { }


      getProducts():Observable<Product[]>{

           return  this._http.get<Product[]>(this.url);


      }


}
