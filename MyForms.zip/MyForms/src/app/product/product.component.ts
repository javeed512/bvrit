import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import {Product} from './product'; 
import { getTypeNameForDebugging } from '@angular/core/src/change_detection/differs/iterable_differs';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

    productObj:Product;

    productList:Product[]=[];

  constructor(private _service:ProductService) { }

  ngOnInit() {


        this.getProducts();

        

      

  }



    updateProduct(data){

        this.productObj = data.value;

            for (let i = 0;  i< this.productList.length; i++) {
              
                  if(this.productObj.pid == this.productList[i].pid){

                      let updateProduct =      this.productList[i];

                                updateProduct.pname = this.productObj.pname;
                                updateProduct.price = this.productObj.price;

                                this.productList[i] = updateProduct;  

                               // this.productList.push(data.value);


                  }

              
            }






    }


    getProducts(){

     this._service.getProducts().subscribe(product => this.productList = product);

    }




    getFormData(data){


        console.log(data.value);

        this.productList.push(data.value);

    }


    getPid(data){

      let  pid:number = data.value.pid;


      for (let i = 0; i < this.productList.length; i++) {
        
        
            if(pid == this.productList[i].pid){

                  this.productList.splice(i,1);


            }


      }
    }


    getPName(data){

      let pname:string = data.value.pname;

        for (let i = 0; i < this.productList.length; i++) {
          

              if (pname == this.productList[i].pname) {

                       this.productObj =     this.productList[i];

                
              }

          
        }






  }




















    }
















