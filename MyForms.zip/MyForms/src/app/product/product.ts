
export class Product{

        pid:number;
        pname:string;
        price:number;



}